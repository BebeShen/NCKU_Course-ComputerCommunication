client的第一個參數是host ip, 第二個是port
server只有一個參數 就是port
編譯過的client.c和server.c會產生執行檔，假設叫做client和serverr
./server 5566
./client localhost 5566
這樣就可以執行了